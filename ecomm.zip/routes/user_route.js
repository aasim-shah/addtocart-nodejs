import  express, { urlencoded }  from 'express';
import users from '../controllers/users_controller.js'
import passport  from 'passport';
import  Jwt from 'jsonwebtoken';
import session from 'express-session';
import  userModel from '../models/userModel.js';
import passportLocal from 'passport-local';
import cookieParser from 'cookie-parser';
const local = passportLocal.Strategy

const router = express.Router()
router.use(urlencoded({extended : false}))
router.use(cookieParser())
const user = new users()
router.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: true }
  }))
router.use(express.json())
router.use(passport.initialize());
router.use(passport.session());

passport.use(new local(
    function(username, password, done) {
      userModel.findOne({ username: username }, function (err, user) {
        if (err) { return done(err); }
        if (!user) { return done(null, false); }
      
        return done(null, user);
      });
    }
  ));

  passport.deserializeUser(function(id, done) {
    User.findById(id, function(err, user) {
      done(err, user);
    });
  });
passport.serializeUser(function(user, done) {
    done(null, user.id);
  });
  
  
//jwt verfication 
 
const Tokenauth = async (req ,res , next)=>{
 try {
  const token = req.cookies.jwt_Token
  const verfiy = await Jwt.verify(token , 'mysupersecret')
  const verfified_user = await userModel.findById(verfiy._id)
  req.user = verfified_user
  next()
 } catch (error) {
   console.log(error)
   res.redirect('/login')
 }
} 





router.get('/', user.home);
router.get('/register', user.registered);
router.post('/register', user.registering);
router.get('/login', user.login_get);
router.post('/login', passport.authenticate('local', { failureRedirect: 'login' }),
user.login_post
);
router.get('/dashboard' , Tokenauth , user.dashboard_get)
router.get('/logout', Tokenauth,  user.logout);

export default router;