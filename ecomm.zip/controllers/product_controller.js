
class products {
    home(req ,res) {
        res.send('oka')
    }
    async  okay(req ,res) {
        res.send('sajdflsjdlfjsalo okay')
    }
}
export default products