
class apps {
    home(req ,res) {
        res.send('homepage')
    }
    async  okay(req ,res) {
        res.send('sajdflsjdlfjsalo okay')
    }
}
export default apps